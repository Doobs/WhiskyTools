self.assetsManifest = {
  "version": "BprJjd0c",
  "assets": [
    {
      "hash": "sha256-xLwPH/kILGqSTgFBsQ1ubAyjl521ZZQ/vsfJnjEIgWY=",
      "url": "WhiskyTools.styles.css"
    },
    {
      "hash": "sha256-DMQw3NWUs/U7rEKi0SlrWFscUmK0mvKwAZOTPbRHltM=",
      "url": "_content/Blazor.Bootstrap/Blazor.Bootstrap.olwso25aue.bundle.scp.css"
    },
    {
      "hash": "sha256-jqE3jyGxWnCTc0Y7oGfHKZOpZM9udgb38MQGLaxmkNc=",
      "url": "_content/Blazor.Bootstrap/blazor.bootstrap.css"
    },
    {
      "hash": "sha256-K2/8DlTnqlDEoF5c6HURzb3R0IK1KrywUAEbLLWNCno=",
      "url": "_content/Blazor.Bootstrap/blazor.bootstrap.js"
    },
    {
      "hash": "sha256-W7yoJQDLn/kp1Hj9hVIhrOf7Y5VHTzRZLnz9+3x6Ocs=",
      "url": "_content/Blazor.Bootstrap/blazor.bootstrap.pdf.js"
    },
    {
      "hash": "sha256-du71NM6e2+m9l81ldV+Gbr74ER7Xx1GnJFg+rIY6OQU=",
      "url": "_content/Blazor.Bootstrap/blazor.bootstrap.sortable-list.js"
    },
    {
      "hash": "sha256-Hy2y6B5ohWPnmWg4c52+QUuZGTw8r09KtWKcaGiaa/k=",
      "url": "_content/Blazor.Bootstrap/blazor.bootstrap.theme-switcher.js"
    },
    {
      "hash": "sha256-J1yB7ftYf6PWiU1781eE0JHBGfd1MV/XlLaxpVy09RU=",
      "url": "_content/Blazor.Bootstrap/icon/128X128.png"
    },
    {
      "hash": "sha256-XX7we2CiSWzj3rsNtKFCod90LBYAJ3bo8rmu4EuN7SQ=",
      "url": "_content/Blazor.Bootstrap/pdfjs-4.0.379.min.js"
    },
    {
      "hash": "sha256-JbwqIn9Fic7JuWyTXuNnAA1T0dYQ2tkTi9HhrSltUtQ=",
      "url": "_content/Blazor.Bootstrap/pdfjs-4.0.379.worker.min.js"
    },
    {
      "hash": "sha256-I8Mw2PV3C0Nu2TW8Uxtb3RtMdMzPYdgaStBM76NP1Mg=",
      "url": "_framework/BlazorBootstrap.zo6lifkmy7.wasm"
    },
    {
      "hash": "sha256-KQfIKW8aVF0+wJ5rkPgPElIyD3/j2vuMPMdB11oehxE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.t3iinpyp3j.wasm"
    },
    {
      "hash": "sha256-lDVuNyWSw6+zMMv8894zc895F76eImaCOC7YA9qa/ac=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.gfcyrjjcay.wasm"
    },
    {
      "hash": "sha256-apjuKEZ9tbWf402SXmIYK03VNjycswAa6vH8zJbBmDw=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.6w9arfc7uk.wasm"
    },
    {
      "hash": "sha256-6yUBaZRRdjD+2beHEykind9O3eO++rJ/rnrmSJFO8wM=",
      "url": "_framework/Microsoft.AspNetCore.Components.l8uk4w86rn.wasm"
    },
    {
      "hash": "sha256-I1V6RT2jU36RMO/udOCdtpwqRuricdlZ0IRsQvGrIKQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.9hvqdnyedj.wasm"
    },
    {
      "hash": "sha256-R8Rvf+ufvlMX05PSWGUXwGm3hty6uCI9EtqBH2FpDIQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.vejc7kiu4g.wasm"
    },
    {
      "hash": "sha256-UUwnFUGVKcfnwTDp5d2PPIYvZb3p3cZn9VEABGLlYu8=",
      "url": "_framework/Microsoft.Extensions.Configuration.b5r9igf1ej.wasm"
    },
    {
      "hash": "sha256-m9k4pt1S3OsB7nhPn3Spu1JjG5ixGwaWDws5UBzaZjs=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3ajkzukr0v.wasm"
    },
    {
      "hash": "sha256-ExwDQeh4MflT5wdsZhstcI97V7nnmc41HC+7m/ePSg0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bio0krwjyk.wasm"
    },
    {
      "hash": "sha256-X78TdTgU/3Pd3qeRvD+qNMFWjhbxTXjduw5WXDir0JY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.1kdc1oztmi.wasm"
    },
    {
      "hash": "sha256-Nw6fMz9mMm8SS3pPrUsobEC9zzLKC6AKDJhHRldk9VA=",
      "url": "_framework/Microsoft.Extensions.Logging.zh7psstrkj.wasm"
    },
    {
      "hash": "sha256-WsA7Qa5Zv/QmtZqrIEQLYVSPd55Hdc1S+2J7y4JQBJ8=",
      "url": "_framework/Microsoft.Extensions.Options.2abh528mcf.wasm"
    },
    {
      "hash": "sha256-QeF3pj2LH3LcaB6cg9nSyYQ6/Pf6RbTkLakVnAwVPXo=",
      "url": "_framework/Microsoft.Extensions.Primitives.vga3bvc9pt.wasm"
    },
    {
      "hash": "sha256-N8RKL2Eil4ZFxIkWa6Uig12+nRHOstda562q7GCs9fE=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.nsfh695mwg.wasm"
    },
    {
      "hash": "sha256-nq24EAAkRjSradov2RxvGsp0CcRKAd/+7WOmBDB2AqM=",
      "url": "_framework/Microsoft.JSInterop.qqq8d34fmv.wasm"
    },
    {
      "hash": "sha256-6AO4w9W34Z5UHZ2D8X7OZsCbBduF2Er15I3OMWF3k4U=",
      "url": "_framework/System.Collections.Concurrent.4dt9zpwg82.wasm"
    },
    {
      "hash": "sha256-zdkPw6mCFlttFdsIe8F08k/+5i8nate6FHZEVZiZwuM=",
      "url": "_framework/System.Collections.Immutable.d4vdffv4qo.wasm"
    },
    {
      "hash": "sha256-ybw1NKbJxAhZzQKe1jBvxZFjXdyBU6vzM268PlEy6ec=",
      "url": "_framework/System.Collections.NonGeneric.55xkw62b0i.wasm"
    },
    {
      "hash": "sha256-1c6AahI314YGxSx8RJyQhPMkLacfIEHRQ5D8MhNvczQ=",
      "url": "_framework/System.Collections.Specialized.disact8epu.wasm"
    },
    {
      "hash": "sha256-+M6KITNT0m7PzSS7X1J5Q7UGuKUUylQlnydVHwnGXFo=",
      "url": "_framework/System.Collections.w6xwx4bzly.wasm"
    },
    {
      "hash": "sha256-zgKONLsqL2JgE61pxQ7tqtPLXdLkrOVrIlTCJIP+NZ4=",
      "url": "_framework/System.ComponentModel.Annotations.2jai1jbu8h.wasm"
    },
    {
      "hash": "sha256-o7RfZ6xylrFo5u7BPYVL1CAsR6x1GrIiwsgtgjypg5o=",
      "url": "_framework/System.ComponentModel.Primitives.7rx3r3kfui.wasm"
    },
    {
      "hash": "sha256-SP07osSZB38Q0Liq5JZ8pf+DfswO/X7CCipxyVhQC88=",
      "url": "_framework/System.ComponentModel.TypeConverter.sn3rmfw11t.wasm"
    },
    {
      "hash": "sha256-/vBQJPKxuZj5hnuVviYGodmh1YjfAeyMqKIaaCNjsuQ=",
      "url": "_framework/System.ComponentModel.i0fo9h67cq.wasm"
    },
    {
      "hash": "sha256-n9RZ8efxpWfvtbJ0TT4UsP9lB918Lw4fGlV+KQ0jxLk=",
      "url": "_framework/System.Console.1o4brl919v.wasm"
    },
    {
      "hash": "sha256-TrsEpPyio4eRSE7Wb7CdsGyGh3jcWRwzDDkcEp42Lxc=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ae3ec8dz20.wasm"
    },
    {
      "hash": "sha256-7C5nXYePF+U/ta0nBxAOwCxBdlDpXVOvuwMa8GG9kt4=",
      "url": "_framework/System.Drawing.Primitives.odw0n5qxem.wasm"
    },
    {
      "hash": "sha256-Aq7ZDZqgNgqw6omxb7ecuy1bcZbpMBzFPW33FM62x0I=",
      "url": "_framework/System.Drawing.aloqfx03tv.wasm"
    },
    {
      "hash": "sha256-vB/mHpU8YWqbonbePTX22jmIRwgl+Gn2euzReK4v7es=",
      "url": "_framework/System.IO.Pipelines.8brogkqzjr.wasm"
    },
    {
      "hash": "sha256-Hnwr+xF01YpyrPuUe7XrDiGXHsBkbpB32JFSDxuOHi4=",
      "url": "_framework/System.Linq.Expressions.2jj5y6xxxm.wasm"
    },
    {
      "hash": "sha256-oOa1z/fjv0EA0VvcHx6IJXf4OBMCYw/WG65xS6gF468=",
      "url": "_framework/System.Linq.kjqh6cxbut.wasm"
    },
    {
      "hash": "sha256-AlZfojZm8NVTzn3cQgdwVfw30NPw6JL18s6LcbhbDOM=",
      "url": "_framework/System.Memory.edyw47qxtr.wasm"
    },
    {
      "hash": "sha256-SN3xREGLMZ4urYFOX4YGJNvHlvQnd7sswd5KevY3WT4=",
      "url": "_framework/System.Net.Http.o8dhoaknvo.wasm"
    },
    {
      "hash": "sha256-bZIyo1/j633N5pQMd0MwhjszHTrpQognOO74FxR9NLI=",
      "url": "_framework/System.Net.Primitives.baq20ve775.wasm"
    },
    {
      "hash": "sha256-JEtFuU4HZIIu9lQgPf4TOdbPwBsV/MQIALa5c75OL8Q=",
      "url": "_framework/System.ObjectModel.cmkzocrqkq.wasm"
    },
    {
      "hash": "sha256-RRpOmLdx9a+IDx9wNHD/MMTYidyHN1AKvrm6NC2tKpw=",
      "url": "_framework/System.Private.CoreLib.3if5ooxiav.wasm"
    },
    {
      "hash": "sha256-nC2OgEVWImRbS/C/BE6Md3JKNrOtjvU6brxf71UYvTg=",
      "url": "_framework/System.Private.Uri.wnsyszy5ky.wasm"
    },
    {
      "hash": "sha256-wxAfbkoX5HawfklOB7UONYXUXRJ24ohuZtnDpw80dhI=",
      "url": "_framework/System.Runtime.5y742jo070.wasm"
    },
    {
      "hash": "sha256-iTel8M+hoSI92c0jJFjN3ENcbqXnumik9GyNDAB4CIA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lpvs49i9za.wasm"
    },
    {
      "hash": "sha256-hNscyDEOuSBQrbfdWj7xo6Xlf8BfHFg1XTqp2Dm2TzQ=",
      "url": "_framework/System.Runtime.Serialization.Primitives.ofdyzo4bf3.wasm"
    },
    {
      "hash": "sha256-OMv0m78kVb0fejHBkAFQR8ppLcZiL/cZYoK1uiRS3rY=",
      "url": "_framework/System.Security.Cryptography.8w3aldlzuj.wasm"
    },
    {
      "hash": "sha256-L7MENY3MC1omCxUNeIHi7wWqDJNuyYwQadXnY5J55nw=",
      "url": "_framework/System.Text.Encodings.Web.zvrg6bb1ih.wasm"
    },
    {
      "hash": "sha256-7kZtRvgnOp6tvzpjDa6wAiNmnC/Tg+cocCojALaclEQ=",
      "url": "_framework/System.Text.Json.2k0l73bvxw.wasm"
    },
    {
      "hash": "sha256-ZFEDYV6FCHM8tTUzsvx10bhQ3iYVNdtBrx/EoDbsUqc=",
      "url": "_framework/System.Text.RegularExpressions.si8p2azqqi.wasm"
    },
    {
      "hash": "sha256-fcZeJpcx95Puk/XzRsdrgEiNvFAMILZMz6hfkexPKp8=",
      "url": "_framework/System.Threading.7jdwdkbyqt.wasm"
    },
    {
      "hash": "sha256-Sd3s9Vn4Uscsky7aa9pkHZrTKzPZT0ckLQ5cMvbAis0=",
      "url": "_framework/System.l5g27qddaj.wasm"
    },
    {
      "hash": "sha256-5ROUUwFDase8sdnWfk4PdWJQ9zFKFYOvBDiXRBRVJUA=",
      "url": "_framework/WhiskyTools.zyf5s8l0db.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.66stpp682q.js"
    },
    {
      "hash": "sha256-Ejj8gYf9mQVhOZRoNLTxus+cl0LLt6PgqoIsR27tI7w=",
      "url": "_framework/dotnet.6zud2anl37.js"
    },
    {
      "hash": "sha256-Jq16DJlsNP/EZy3u5dUfhPu0r4vqciQE3d0LSaelSes=",
      "url": "_framework/dotnet.native.2qba9g5fwn.wasm"
    },
    {
      "hash": "sha256-uQpMf2vCY3ZTY+nV2gmp8VdAe67PW6h1gInkE7r/PLY=",
      "url": "_framework/dotnet.native.xanz2e7ksm.js"
    },
    {
      "hash": "sha256-yJvgPPUUvavYVmu9VD/fYtMcoEnLVaB0Cr7JAE29btw=",
      "url": "_framework/dotnet.runtime.o0qy896u8v.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-3mQKRvLisQ7O2jBPk5iudU95guoF0VHTNEMnV9hXM0o=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-sEnx5Dujk2OXknf8/TdGxa7VQb6OLXbKdqPSII5RZlM=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-7NG5VuZd99cd/Y+tDBs8IwQdHQTX+Q+RlYVprw/9NvI=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-Jg1UBJSfzNrDiCOHRSTVWIIOCLwIaXIiflb4HY/jl1w=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-dWofM0m4HYO2MsoLXMAB2oEfavJKxrHoWqQTpS/guXU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-QWmrzBhUOGeYXVQ5X/L8YRJEbn4yp6CTiceBcMTX0Qg=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-BSudNoERRnZi8VkT7Z7SdkRHU7/syl2FDF+PSQq0BS8=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-LZ3YSIvDIilWUOZ2b1Hj5Hzum6vEF71KPnetoM6fspc=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-wIdG8lWZMdLaWPbf+qT/u/yV544RYAragaptY38jSW8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-5xOkUT1sQwwyESieLDMJjxNQEAiqKoE7ziDD13psK3c=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-TvC8H8WjuHA5e0miejGSgbnrzyNt9eSg7OEHZEYstAk=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-G3dD3kYmxoDaNbSMhKBb3RWmNJon7sl/GGdK1p5bXVw=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-9AmcQvaRpm/zQeIXrqc79T9I6Cq5q2AHRtKL/432TSc=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-0Zbn58ulonNXO6K1HFirxMdEh1TWFZQV3SC90G5b1OA=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-GosNogWyUk+Du1cODrXHhZVZFcO2uUOu8og2y35qCKg=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-qs6a5RMctUBdBpiPxpRHmzuvGeIx1Ir/yt6i0a5W8Yw=",
      "url": "whiskytools-nameplate.png"
    }
  ]
};
